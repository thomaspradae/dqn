from __future__ import annotations

import unittest

import numpy as np

from dejong3d.animation import build_animation, interpolate_spec, neutral_spec
from dejong3d.models import RenderConfig, VariantSearchConfig


class AnimationTests(unittest.TestCase):
    def setUp(self):
        self.render = RenderConfig(term_width=36, term_height=18, supersample=2)
        self.search = VariantSearchConfig(candidates_per_code=2, modes=("surface",))

    def test_endpoints_are_exact(self):
        assets, target, frames, specs = build_animation(
            "test:node", render_cfg=self.render, search_cfg=self.search, frames=5, mode="surface"
        )
        self.assertTrue(np.array_equal(frames[0], assets["canonical_term"]))
        self.assertTrue(np.array_equal(frames[-1], target.term))

    def test_deterministic_target(self):
        _, target_a, frames_a, _ = build_animation(
            "test:determinism", render_cfg=self.render, search_cfg=self.search, frames=4, mode="surface"
        )
        _, target_b, frames_b, _ = build_animation(
            "test:determinism", render_cfg=self.render, search_cfg=self.search, frames=4, mode="surface"
        )
        self.assertEqual(target_a.manifest_record()["spec"], target_b.manifest_record()["spec"])
        self.assertTrue(np.array_equal(frames_a[-1], frames_b[-1]))

    def test_interpolation_hits_target(self):
        _, target, _, _ = build_animation(
            "test:interp", render_cfg=self.render, search_cfg=self.search, frames=3, mode="surface"
        )
        start = neutral_spec(target.spec)
        end = interpolate_spec(start, target.spec, 1.0)
        self.assertAlmostEqual(end.yaw_deg, target.spec.yaw_deg)
        self.assertAlmostEqual(end.pitch_deg, target.spec.pitch_deg)
        self.assertAlmostEqual(end.depth, target.spec.depth)
        self.assertAlmostEqual(end.twist, target.spec.twist)


if __name__ == "__main__":
    unittest.main()
