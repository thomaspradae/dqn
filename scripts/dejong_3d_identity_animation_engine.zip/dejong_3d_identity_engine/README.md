# De Jong 3D identity engine

This package builds a deterministic 3D identity system around one canonical De Jong logo.

Canonical source:

- family: `dejong`
- seed: `poormans-hpc:dejong:00012`
- rank: `9`
- raw score: `8.470892`
- selection score: `9.039588`
- params:
  - `a = 1.1504140582765`
  - `b = -2.3598824892870325`
  - `c = 2.223958296969601`
  - `d = -1.9009456070297253`

## What it does

1. Regenerates the exact 2D De Jong point cloud from those fixed parameters.
2. Turns that point cloud into a normalized master density field.
3. Lifts the 2D logo into 3D in several different derivation modes.
4. Applies deterministic 3D rotation, twist, and projection derived from a code/hash.
5. Searches a deterministic neighborhood per code and keeps the best identity-preserving variant.
6. Renders the result to terminal-density art and exports an HTML gallery plus metadata.

## 3D derivation modes

- `surface`: density-driven relief surface with layered volume.
- `contour_stack`: topographic slice stack derived from density contours.
- `ribbon_skeleton`: trajectory-based ribbon/tube interpretation of the attractor path.
- `shell_relief`: inflated embossed shell using the canonical silhouette as a mother-form.

## Run

```bash
python3 -m pip install -r requirements.txt
python3 generate_identity_variants.py --out /tmp/dejong3d_gallery --seed poormans-hpc --count 16
xdg-open /tmp/dejong3d_gallery/index.html
```

Restrict to one or more modes:

```bash
python3 generate_identity_variants.py --out /tmp/dejong3d_shell --modes shell_relief
python3 generate_identity_variants.py --out /tmp/dejong3d_mix --modes surface ribbon_skeleton shell_relief
```

## Notes

- `canonical` is always included as the first output.
- every other code is deterministic; the same code always yields the same chosen variant.
- the engine is 3D internally, but the exported mark is a 2D projection of that 3D form.
- if you want more exploration per code, increase `--candidates-per-code`.

## Animated identity transition

The animation layer treats the canonical logo as frame zero and a deterministic 3D descendant as the final frame.

For a node or arbitrary code:

```bash
python3 animate_identity.py node:ofi1
```

The default motion is:

1. hold the exact canonical 2D De Jong mark briefly;
2. introduce depth;
3. begin camera rotation;
4. bring in twist/ripple detail slightly later;
5. end on the exact deterministic 3D target selected for that code.

Useful controls:

```bash
python3 animate_identity.py node:ofi1 --seconds 2 --fps 24
python3 animate_identity.py node:ofi1 --pingpong --loop 3
python3 animate_identity.py node:ofi1 --style binary
python3 animate_identity.py node:ofi1 --mode contour_stack
```

Export all text frames plus a self-playing browser preview:

```bash
python3 animate_identity.py node:ofi1 \
  --frames 49 --fps 24 \
  --export /tmp/ofi1-animation \
  --no-play

xdg-open /tmp/ofi1-animation/index.html
```

### Playback quality decisions

- Every animation is precomputed before playback to avoid render-time stutter.
- Frame zero is exactly the canonical renderer output.
- The last frame is exactly the selected deterministic descendant.
- Continuous parameters use smooth eased interpolation.
- Rotation begins slightly after depth starts changing, so the mark reads as unfolding into a 3D object.
- Terminal output is emitted in one write per frame to reduce tearing.
- Playback uses the alternate screen and hides/restores the cursor safely.
- Frame pacing uses a monotonic clock instead of accumulating `sleep()` drift.
- The renderer automatically shrinks to fit the active terminal unless `--no-auto-fit` is used.

### Tests

```bash
python3 -m unittest discover -s tests -v
```

The test suite checks exact canonical/final endpoints and deterministic reproduction of a code-specific target.
