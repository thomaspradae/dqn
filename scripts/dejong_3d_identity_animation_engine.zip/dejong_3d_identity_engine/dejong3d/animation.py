from __future__ import annotations

from dataclasses import replace
import html
import json
import math
from pathlib import Path
import sys
import time

import numpy as np

from .models import CanonicalSpec, RenderConfig, VariantRecord, VariantSearchConfig, VariantSpec
from .render import ASCII_RAMP, SHADE_RAMP, terminal_to_binary, terminal_to_text, text_block
from .search import build_canonical_assets, choose_best_variant, render_variant


def smootherstep(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0)


def ease_in_out_sine(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return -(math.cos(math.pi * t) - 1.0) / 2.0


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _shortest_angle_lerp(a: float, b: float, t: float) -> float:
    delta = (b - a + 180.0) % 360.0 - 180.0
    return a + delta * t


def neutral_spec(target: VariantSpec) -> VariantSpec:
    """A flat front-facing state using the target's discrete topology.

    Discrete choices (mode/frequencies/layer count) are fixed from frame zero.
    Their amplitudes begin at zero, so they do not pop into view midway.
    """
    return replace(
        target,
        yaw_deg=0.0,
        pitch_deg=0.0,
        roll_deg=0.0,
        depth=0.0,
        gamma=1.0,
        thickness=0.0,
        ripple_x_amp=0.0,
        ripple_y_amp=0.0,
        ripple_r_amp=0.0,
        twist=0.0,
        perspective=0.0,
        focal=3.0,
        camera_z=3.0,
        search_index=target.search_index,
    )


def interpolate_spec(start: VariantSpec, end: VariantSpec, t: float) -> VariantSpec:
    """Interpolate only continuous state; discrete geometry remains the target's."""
    e = smootherstep(t)
    # Camera gets a slightly delayed ease so the object first acquires depth,
    # then visibly turns. This reads better than changing everything at once.
    camera_e = smootherstep(max(0.0, min(1.0, (t - 0.08) / 0.92)))
    detail_e = smootherstep(max(0.0, min(1.0, (t - 0.16) / 0.84)))
    return replace(
        end,
        yaw_deg=_shortest_angle_lerp(start.yaw_deg, end.yaw_deg, camera_e),
        pitch_deg=_shortest_angle_lerp(start.pitch_deg, end.pitch_deg, camera_e),
        roll_deg=_shortest_angle_lerp(start.roll_deg, end.roll_deg, camera_e),
        depth=_lerp(start.depth, end.depth, e),
        gamma=_lerp(start.gamma, end.gamma, e),
        thickness=_lerp(start.thickness, end.thickness, e),
        ripple_x_amp=_lerp(start.ripple_x_amp, end.ripple_x_amp, detail_e),
        ripple_y_amp=_lerp(start.ripple_y_amp, end.ripple_y_amp, detail_e),
        ripple_r_amp=_lerp(start.ripple_r_amp, end.ripple_r_amp, detail_e),
        twist=_lerp(start.twist, end.twist, detail_e),
        perspective=_lerp(start.perspective, end.perspective, camera_e),
        focal=_lerp(start.focal, end.focal, camera_e),
        camera_z=_lerp(start.camera_z, end.camera_z, camera_e),
    )


def build_animation(
    code: str,
    render_cfg: RenderConfig | None = None,
    search_cfg: VariantSearchConfig | None = None,
    canonical_spec: CanonicalSpec | None = None,
    frames: int = 48,
    mode: str = "surface",
) -> tuple[dict[str, object], VariantRecord, list[np.ndarray], list[VariantSpec]]:
    render_cfg = render_cfg or RenderConfig()
    base_search = search_cfg or VariantSearchConfig()
    # Animation defaults to one geometry mode so there is no topology switch mid-motion.
    animation_search = replace(base_search, modes=(mode,))
    canonical_spec = canonical_spec or CanonicalSpec()
    assets = build_canonical_assets(render_cfg, canonical_spec)
    target = choose_best_variant(code, assets, render_cfg, animation_search)
    start = neutral_spec(target.spec)

    frames = max(2, int(frames))
    terms: list[np.ndarray] = []
    specs: list[VariantSpec] = []
    for i in range(frames):
        t = i / (frames - 1)
        if i == 0:
            # Frame zero is bit-for-bit the canonical 2D renderer.
            term = np.array(assets["canonical_term"], copy=True)
            spec = start
        elif i == frames - 1:
            # Last frame is exactly the chosen deterministic descendant.
            term = np.array(target.term, copy=True)
            spec = target.spec
        else:
            spec = interpolate_spec(start, target.spec, t)
            term = render_variant(spec, assets["base_points"], assets["densities"], render_cfg)
        terms.append(term)
        specs.append(spec)
    return assets, target, terms, specs


def frame_to_text(term: np.ndarray, render_cfg: RenderConfig, style: str = "shade") -> str:
    if style == "binary":
        lines = terminal_to_binary(term, render_cfg.ink_threshold)
    elif style == "ascii":
        lines = terminal_to_text(term, ASCII_RAMP, render_cfg.gamma)
    else:
        lines = terminal_to_text(term, SHADE_RAMP, render_cfg.gamma)
    return text_block(lines, render_cfg.term_width)


def playback_terminal(
    terms: list[np.ndarray],
    render_cfg: RenderConfig,
    fps: float = 24.0,
    style: str = "shade",
    hold: float = 0.8,
    intro_hold: float = 0.30,
    loop: int = 1,
    pingpong: bool = False,
    alt_screen: bool = True,
) -> None:
    fps = max(1.0, float(fps))
    interval = 1.0 / fps
    frames = list(terms)
    if pingpong and len(frames) > 2:
        frames = frames + frames[-2:0:-1]
    enter = "\x1b[?1049h" if alt_screen else ""
    leave = "\x1b[?1049l" if alt_screen else ""
    sys.stdout.write(enter + "\x1b[?25l\x1b[2J\x1b[H")
    sys.stdout.flush()
    try:
        if intro_hold > 0 and frames:
            sys.stdout.write("\x1b[H" + frame_to_text(frames[0], render_cfg, style))
            sys.stdout.flush()
            time.sleep(intro_hold)
        loops = max(1, int(loop))
        for _ in range(loops):
            deadline = time.monotonic()
            for term in frames:
                payload = frame_to_text(term, render_cfg, style)
                # One write per frame prevents line-by-line tearing/flicker.
                sys.stdout.write("\x1b[H" + payload)
                sys.stdout.flush()
                deadline += interval
                delay = deadline - time.monotonic()
                if delay > 0:
                    time.sleep(delay)
        if hold > 0:
            time.sleep(hold)
    finally:
        sys.stdout.write("\x1b[?25h" + leave)
        sys.stdout.flush()


def export_frames(
    out_dir: Path,
    terms: list[np.ndarray],
    specs: list[VariantSpec],
    target: VariantRecord,
    render_cfg: RenderConfig,
    fps: float,
    style: str = "shade",
) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    texts: list[str] = []
    for i, term in enumerate(terms):
        text = frame_to_text(term, render_cfg, style)
        texts.append(text)
        (out_dir / f"frame_{i:04d}.txt").write_text(text + "\n", encoding="utf-8")
    manifest = {
        "engine": "dejong-3d-identity-animation",
        "code": target.code,
        "mode": target.spec.mode,
        "fps": fps,
        "frame_count": len(terms),
        "target": target.manifest_record(),
        "frames": [
            {
                "index": i,
                "yaw_deg": specs[i].yaw_deg,
                "pitch_deg": specs[i].pitch_deg,
                "roll_deg": specs[i].roll_deg,
                "depth": specs[i].depth,
                "twist": specs[i].twist,
                "perspective": specs[i].perspective,
            }
            for i in range(len(specs))
        ],
    }
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    js_frames = json.dumps(texts)
    duration_ms = max(16, round(1000.0 / max(fps, 1.0)))
    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>De Jong identity animation</title>
<style>
:root{{color-scheme:dark}}body{{margin:0;background:#080c12;color:#e6edf3;font:14px system-ui,sans-serif;display:grid;min-height:100vh;place-items:center}}
.wrap{{width:min(94vw,900px)}}.meta{{color:#8b98aa;margin-bottom:12px}}pre{{margin:0;background:#030609;border:1px solid #263143;border-radius:10px;padding:18px;overflow:auto;font:14px/1 monospace;white-space:pre}}
button{{margin-top:12px;background:#111a27;color:#e6edf3;border:1px solid #263143;border-radius:6px;padding:6px 10px}}
</style>
</head><body><div class="wrap"><div class="meta">{html.escape(target.code)} · {html.escape(target.spec.mode)} · {len(terms)} frames · {fps:g} fps</div><pre id="screen"></pre><button id="toggle">pause</button></div>
<script>
const frames={js_frames}; let i=0, playing=true; const screen=document.getElementById('screen');
function tick(){{if(playing){{screen.textContent=frames[i];i=(i+1)%frames.length}}}} screen.textContent=frames[0]; setInterval(tick,{duration_ms});
document.getElementById('toggle').onclick=()=>{{playing=!playing;document.getElementById('toggle').textContent=playing?'pause':'play'}};
</script></body></html>"""
    path = out_dir / "index.html"
    path.write_text(page, encoding="utf-8")
    return path
